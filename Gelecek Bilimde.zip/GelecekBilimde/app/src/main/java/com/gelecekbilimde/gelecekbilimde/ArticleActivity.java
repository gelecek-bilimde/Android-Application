package com.gelecekbilimde.gelecekbilimde;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toolbar;

public class ArticleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_article);

        Toolbar toolbar =  findViewById(R.id.article_search_bar);
        setSupportActionBar(toolbar);
    }
}
